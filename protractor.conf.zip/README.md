# Angular-with-Redux
A Fleet Management Application built using Angular/Redux/.Net core and MongoDB
